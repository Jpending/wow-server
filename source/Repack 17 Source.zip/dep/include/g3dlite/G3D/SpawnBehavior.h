#ifndef SpawnBehavior_h
#define SpawnBehavior_h
namespace G3D {
enum SpawnBehavior {USE_NEW_THREAD, USE_CURRENT_THREAD};
}
#endif
